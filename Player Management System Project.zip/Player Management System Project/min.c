#include<stdio.h>
void main()
{
	int arr[6];
	int i;
	
	for(i=0;i<6;i++)
	{
		printf("\n  Enter %d element ",i);
	    scanf(" %d",&arr[i]);
	}
	int min=arr[0];
	for(i=0;i<6;i++)
	{
		if (min>arr[i])
		{
		
		min=arr[i];
	    }
	}
	printf("Minimum number is : %d \n",min);
	
	int max=arr[0];
	for(i=0;i<5;i++)
	{
		if (max<arr[i])
		{
			max=arr[i];	
		}
	}
	printf("Maximum number is : %d ",max);
}