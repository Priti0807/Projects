#include<iostream>
using namespace std;
#include<string.h>
#include"player.h"
	Player :: Player()
	{
		this->jno=0;
		strcpy(this->name,"Not Given !!");
		this->no_of_matches=0;
		this->no_of_runs=0;
		this->no_of_wickets=0;
	}
	Player :: Player(int jno,const char* name, int match,int runs, int wicket)
	{
		this->jno=jno;
		strcpy(this->name,name);
		this->no_of_matches=match;
		this->no_of_runs=runs;
		this->no_of_wickets=wicket;
	}
	void Player :: setJNo(int jno)
	{
		this->jno=jno;
	}
	void Player :: setName(const char* name)
	{
		strcpy(this->name,name);
	}
	void Player :: setMatch(int match)
	{
		this->no_of_matches=match;
	}
	void Player :: setRun(int run)
	{
		this->no_of_runs=run;
	}
	void Player :: setWickets(int wicket)
	{
		this->no_of_wickets=wicket;
	}
	
	int Player :: getJNo()
	{
		return this->jno;
	}
	char* Player :: getName()
	{
		return this->name;
	}
	int Player :: getMatch()
	{
		return this->no_of_matches;
	}
	int Player :: getRuns()
	{
		return this->no_of_runs;
	}
	int Player :: getWickets()
	{
		return this->no_of_wickets;
	}
	void Player :: displayData()
	{	
		cout<<"\nJersey No: "<<this->jno<<"\t\t";
		cout<<"Name: "<<this->name<<"\t\t";
		cout<<"No of matches: "<<this->no_of_matches<<"\t\t";
		cout<<"No of Runs: "<<this->no_of_runs<<"\t\t";
		cout<<"No of wickets "<<this->no_of_wickets<<"\t\n";
	}
	
