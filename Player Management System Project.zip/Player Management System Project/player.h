class Player
{
	int jno;
	char name[30];
	int no_of_matches;
	int no_of_wickets;
	int no_of_runs;
	public:
		Player();
		Player(int ,const char*, int ,int, int);
		void setJNo(int);
		void setName(const char*);
		void setMatch(int);
		void setRun(int);
		void setWickets(int);
		int getJNo();
		char* getName();
		int getMatch();
		int getRuns();
		int getWickets();
		void displayData();
};