#include<iostream>
using namespace std;
//#include "player.h"
#include "playermanagement.cpp"
int main()
{
	PlayerManagement <Player> pm;
	int choice;
	do
	{
		cout<<"\n\t1.Show Player\n\t2.Add Player\n\t3.Delete Player\n\t4.Search Player\n\t5.Sort Players\n\t6.Update Player Information\n\t7.Top 3 Player\n\t0.Exit\nEnter Choice: ";
		cin>>choice;
		switch(choice)
		{
			case 1:
				{
					pm.display();
					break;
				}
			case 2:
				{
					
					int jno,pos;
					cout<<"\n Enter Position: ";
					cin>>pos;
					
					cout<<"\nEnter Jersey No: ";
					cin>>jno;
					
					fflush(stdin);
					char name[30];
					cout<<"\nEnter Name: ";
					cin.getline(name,30);
					
					int no_of_matches;
					cout<<"\nEnter No of matches: ";
					cin>>no_of_matches;
					
					int no_of_runs;
					cout<<"\nEnter No of Runs: ";
					cin>>no_of_runs;
					
					int no_of_wickets;
					cout<<"\nEnter No of wickets: ";
					cin>>no_of_wickets;
					
					Player p1(jno,name,no_of_matches,no_of_runs,no_of_wickets);
					pm.addPlayer(p1,pos);
					break;
				}
			case 3:
				{
					int jno;
					cout<<"\n Enter Jersey No: ";
					cin>>jno;
					pm.deletePlayer(jno);
					break;
				}	
			case 4:
				{
					int ch;
					do
					{
						cout<<"\n\t1.Search By Jersey Number\n\t2.Search By Name \n\t0.Exit\nEnter Choice: ";
						cin>>ch;
						switch(ch)
						{
							case 1:
								{
									int jno;
									cout<<"\n Enter Jersey number to search: ";
									cin>>jno;
									Node<Player>* q;
									q=pm.searchPlayerId(jno);
									q->getData().displayData();						
									break;
								}
							case 2:
								{
									fflush(stdin);
									char name[20];
									cout<<"Enter Name: ";
									cin.getline(name,20);
									Node<Player>* t;
									t=pm.searchPlayerName(name);
									t->getData().displayData();
									
									break;
								}	
						}
						
					}
					while(ch!=0);
					break;
				}	
			case 5:
				{
					pm.sortPlayer();
					break;
				}	
			case 6:
				{
					pm.updatePlayerInfo();	
					break;
				}	
			case 7:
				{
					pm.topThreePlayer();
					break;
				}	
		}
		
		
	}
	while(choice!=0);
}