#include<iostream>
using namespace std;
#include "player.h"
template<class T>
class Node
{
	Player data;
	Node<T>* next;
	public:
		Node(T);
		Player getData();
		Node<T>* getNext();
		void setData(T);
		void setNext(Node*);
};