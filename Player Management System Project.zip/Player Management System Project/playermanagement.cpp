#include "playermanagement.h"
#include<fstream>
#include<string.h>
template <class T>
PlayerManagement<T>::PlayerManagement()
{
	start=NULL;
	readData();
}
template <class T>
void PlayerManagement<T>::addPlayer(T data,int pos)
{
	Node<T>* temp=new Node<T>(data);
	
		if(pos==1||start==NULL)
		{
			temp->setNext(start);
			start=temp;	
			return;
		}
		Node<T>* p=start;
		int i=1;
		while(i<pos-1&&p->getNext()!=NULL)
		{
			p=p->getNext();
			i++;
		}
		temp->setNext(p->getNext());
		p->setNext(temp);
	
}
template <class T>
void PlayerManagement<T>::deletePlayer(int jno)
{
	if(start==NULL)
	{
		cout<<"No nodes to display";
		return;
	}
	Node<T>* p=start;
	if(start->getData().getJNo()==jno)
	{
		start=p->getNext();
		delete p;
		cout<<"\n Player deleted Successfullyy...";
		return;
	}
	if(start->getNext()==NULL)
	{
		cout<<"Player Not found...";
		return;
	}
	p=start;
	
	Player pl=start->getNext()->getData();
	
	while(pl.getJNo()!=jno && p->getNext()->getNext()!=NULL)
	{
		p=p->getNext();
		pl=p->getNext()->getData();
	}
	if(pl.getJNo()==jno)
	{
		Node<T>* q=p->getNext();
		p->setNext(q->getNext());
		delete q;
		cout<<"\n Player deleted Successfullyy...";
		return;
	}
	else
	{
		cout<<"\nPlayer not found...";
	}	
}
template <class T>
Node<T>* PlayerManagement<T>::searchPlayerId(int& jno)
{
	if(start==NULL)
	{
		cout<<"Players not present...";
		//return;
	}

	Node<T>* p=start;
	while(p->getNext()!=NULL&&p->getData().getJNo()!=jno)
	{
		p=p->getNext();
	}
		if(p->getData().getJNo()==jno)
		{
			cout<<"Player present";		
			return p;
		}
		else
		{
			cout<<"Player Not found...";
			return p;
		}
	
	
}
template <class T>
Node<T>* PlayerManagement<T>::searchPlayerName(const char* name) 
{
	if(start==NULL)
	{
		cout<<"No Player present...";
	//	return;
	}

	Node<T>* p=start;
	while(p->getNext()!=NULL&&(strcasecmp(p->getData().getName(),name)!=0))
	{
		p=p->getNext();
	}
		if(strcasecmp(p->getData().getName(),name)==0)
		{
			cout<<"Player present";
			return p;
		}
		else
		{
			cout<<"Player Not found...";
			return p;
		}
	
}
template <class T>
void PlayerManagement<T>::sortPlayer()
{
	int choice;
	cout<<"\n\t1.Sort By Runs\n\t2.Sort By Wickets\nEnter Choice to Sort player: ";
	cin>>choice;
	if(choice==1)
	{
		if(start==NULL)
		{
			cout<<"No player present....";
			return;
		}
		for(Node<T>* p=start;p!=NULL;p=p->getNext())
		{
			for(Node<T>* q=p->getNext();q!=NULL;q=q->getNext())
			{
				if(p->getData().getRuns()<q->getData().getRuns())
				{																																																							
					Player temp=p->getData();
					p->setData(q->getData());
					q->setData(temp);
				}
			}
		}
		display();
	}
	else if(choice==2)
	{
		if(start==NULL)
		{
			cout<<"No player present....";
			return;
		}
		for(Node<T>* p=start; p!=NULL; p=p->getNext())
		{
			for(Node<T>* q=p->getNext(); q!=NULL; q=q->getNext())
			{
				if(p->getData().getWickets()<q->getData().getWickets())
				{
					Player temp=p->getData();
					p->setData(q->getData());
					q->setData(temp);
				}
			}
		}
		display();
	}
}
template <class T>
void PlayerManagement<T>::updatePlayerInfo()
{
	if(start == NULL)
    {
        cout << "No data present to update";
        return;
    }

    int jno;
    cout << "Enter jersey number to update: ";
    cin >> jno;

    Node<T>* p = start;
    while(p != NULL && p->getData().getJNo() != jno)
    {
        p = p->getNext();
    }

    if(p == NULL)
    {
        cout << "Player with jersey number " << jno << " not found";
        return;
    }

    Player p1 = p->getData();
    int choice;
    cout<<"\n\t1.By Runs\n\t2.By Wickets\n\t3.By Mathces\nEnter choice to update Data: ";
    cin>>choice;
    if(choice==1)
    {
    	int run;
    	cout<<"\nEnter Runs to update: ";
    	cin>>run;
    	p1.setRun(run);
    	p->setData(p1);
    	cout << "\nInformation updated successfully";
    	display();
	}
	else if(choice==2)
	{
		int wicket;
		cout<<"\nEnter Wickets to update: ";
		cin>>wicket;
		p1.setWickets(wicket);
		p->setData(p1);
		cout << "\nInformation updated successfully";
		display();
	}
	else if(choice==3)
	{
		int match;
		cout<<"\nEnter matches to update: ";
		cin>>match;
		p1.setMatch(match);
		p->setData(p1);
		cout << "\nInformation updated successfully";
		display();
	}
}
template <class T>
void PlayerManagement<T>::topThreePlayer()
{
	int choice;
	cout<<"\n\t1.By Runs\n\t2.By Wickets\nEnter Choice to check Top 3 player: ";
	cin>>choice;
	if(choice==1)
	{
		if(start==NULL)
		{
			cout<<"No player present....";
			return;
		}
		
			for(Node<T>* p=start;p!=NULL;p=p->getNext())
			{
				for(Node<T>* q=p->getNext();q!=NULL;q=q->getNext())
				{
					if(p->getData().getRuns()<q->getData().getRuns())
					{
						Player temp=p->getData();
						p->setData(q->getData());
						q->setData(temp);
					}
				}
			}
		Node<T>* p=start;
		int i=1;
		while(p->getNext()!=NULL&&i<3)
		{
			p->getData().displayData();
			p=p->getNext();
			i++;
		}
		p->getData().displayData();
		
	}
	else if(choice==2)
	{
		if(start==NULL)
		{
			cout<<"No player present....";
			return;
		}
		
			for(Node<T>* p=start;p!=NULL;p=p->getNext())
			{
				for(Node<T>* q=p->getNext();q!=NULL;q=q->getNext())
				{
					if(p->getData().getWickets()<q->getData().getWickets())
					{
						Player temp=p->getData();
						p->setData(q->getData());
						q->setData(temp);
					}
				}
			}
		Node<T>* p=start;
		int i=1;
		while(p->getNext()!=NULL&&i<3)
		{
			p->getData().displayData();
			p=p->getNext();
			i++;
		}
		p->getData().displayData();
	}
	
}
template <class T>
void PlayerManagement<T>::writeData()
{
	Node<T>* p=start;
	ofstream out("PlayerInfo.dat",ios_base::binary);
	while(p!=NULL)
	{
		Player p1=p->getData();
		out.write((char*)&p1,sizeof(p1));
		p=p->getNext();
		
		cout<<"\nData added in File SuccessFully...\n";
	}
	out.close();
}
template <class T>
void PlayerManagement<T>::readData()
{
	cout<<"read";
	
	int i=1;
	ifstream in("PlayerInfo.dat",ios_base::binary);
	if(!in)
	{
		cout<<"File does not exist!!!!";
	}
	else
	{
		while(!in.eof())
		{
			Player p1;
			in.read((char*)&p1,sizeof(p1));
			{
				if(in.eof())
				{
					break;
				}
				addPlayer(p1,i);
				i++;
			}
		}
		in.close();
	}	
}
template <class T>
void PlayerManagement<T>::display()
{
	if(start==NULL)
	{
		cout<<"\nNo Player to display";
		return;
	}
	else
	{
		Node<T>* p=start;
		while(p->getNext()!=NULL)
		{
			p->getData().displayData();
			p=p->getNext();
		}
		p->getData().displayData();
	}
}
template <class T>
PlayerManagement<T>::~PlayerManagement()
{
	writeData();
	Node<T>* p=start;
	while(start!=NULL)
	{
		start=start->getNext();
		delete p;
		p=start;
		cout<<"\nDestructor Called...\n";
	}
}