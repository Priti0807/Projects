#include "node.cpp"
template <class T>
class PlayerManagement
{
	Node<T>* start;
	public:
		PlayerManagement();
		void addPlayer(T,int);
		void deletePlayer(int);
		Node<T>* searchPlayerId(int&);
		Node<T>* searchPlayerName(const char*);
		void sortPlayer();
		void updatePlayerInfo();
		void topThreePlayer();
		void display();	
		void writeData();
		void readData();
		~PlayerManagement();
};