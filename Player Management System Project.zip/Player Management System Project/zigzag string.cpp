#include<iostream> 
using namespace std; 
int main() { 
 char str[100]="hellothisisusera"; 
 int len=strlen(str),n; 
 cout<<"enter n"; 
 cin>>n; 
 //int n=3; 
 int i,j,c=0; 
 for(i=1; c<=len; i++)  
 { 
  if(i>=n+1)  
  { 
   for(j=n-1; j>1; j--)  
   { 
    for(int k=1;k<j;k++) 
    { 
     cout<<" "; 
    } 
    cout<<str[c++]<<"\n"; 
   } 
   i=0; 
  } 
  for(int k=1;k<i;k++) 
  { 
   cout<<" "; 
  } 
  if(i!=0) 
  cout<<str[c++]<<"\n"; 
 } 
}